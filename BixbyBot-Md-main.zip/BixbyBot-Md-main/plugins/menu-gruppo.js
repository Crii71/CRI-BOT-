const _0x5f520b = _0x266e;
(function (_0x5036f1, _0x321bf8) {
    const _0x3f28d0 = _0x266e, _0x572665 = _0x5036f1();
    while (!![]) {
        try {
            const _0x27c87b = -parseInt(_0x3f28d0(0x17e)) / (-0x4fc + 0x1 * 0xd96 + -0x899) * (-parseInt(_0x3f28d0(0x18a)) / (0x1237 * 0x2 + -0x101 * -0x3 + -0xd25 * 0x3)) + -parseInt(_0x3f28d0(0x183)) / (-0x2f5 * -0x1 + -0x1 * -0x719 + 0xa0b * -0x1) * (parseInt(_0x3f28d0(0x19c)) / (-0x1 * -0x8de + 0x1 * -0x8dd + 0x3)) + -parseInt(_0x3f28d0(0x18b)) / (-0x2bf * 0x1 + -0x2f * 0x5b + 0x1 * 0x1379) * (-parseInt(_0x3f28d0(0x180)) / (-0x1c10 * -0x1 + 0x26d9 + -0x42e3)) + -parseInt(_0x3f28d0(0x162)) / (0x1738 + 0xb * 0x197 + -0x28ae) + -parseInt(_0x3f28d0(0x1ac)) / (-0x667 + 0x24b * 0x3 + -0x72) + parseInt(_0x3f28d0(0x174)) / (0x1 * 0x50b + 0xa91 * 0x2 + 0x1c * -0xef) * (parseInt(_0x3f28d0(0x177)) / (-0x1726 + 0x1 * 0x11c + 0x1614)) + -parseInt(_0x3f28d0(0x15d)) / (-0x10ac + -0xf07 * 0x2 + 0x2ec5) * (-parseInt(_0x3f28d0(0x1ad)) / (0x1851 + 0x5 * 0x5b5 + 0x119a * -0x3));
            if (_0x27c87b === _0x321bf8)
                break;
            else
                _0x572665['push'](_0x572665['shift']());
        } catch (_0x159d29) {
            _0x572665['push'](_0x572665['shift']());
        }
    }
}(_0x30fe, -0xc99e + 0xe5 * 0x2c9 + 0xc7edf));
import _0x4cc6d7 from 'os';
import _0x4a02be from 'util';
function _0x30fe() {
    const _0x8a023f = [
        'chats',
        '𝐯𝐢𝐝𝐞𝐨\x20(\x20𝐜𝐚𝐧𝐳𝐨𝐧𝐞\x20+\x20𝐚𝐫𝐭𝐢𝐬𝐭𝐚\x20)\x20\x0a-\x20',
        'uptime',
        'cBuYL',
        'https://telegra.ph/file/2f38b3fd9cfba5935b496.jpg',
        'SqErr',
        '𝐦𝐞𝐭𝐞𝐨\x20(\x20𝐜𝐢𝐭𝐭𝐚\x27\x20)\x0a-\x20',
        '33687LfekAg',
        'ARHsG',
        'isChats',
        '1310BNUKKA',
        '𝐫𝐢𝐯𝐞𝐥𝐚\x20(\x20𝐟𝐨𝐭𝐨¹\x20)\x0a-\x20',
        '𝐞𝐥𝐢𝐦𝐢𝐧𝐚𝐢𝐠\x0a-\x20',
        '𝐢𝐦𝐠\x0a-\x20',
        '𝐚𝐮𝐭𝐨𝐚𝐝𝐦𝐢𝐧\x0a──────────────',
        'settings',
        '𝐝𝐨𝐱\x20@\x0a-\x20',
        '100687AHcMIb',
        'data',
        '12PdTPsK',
        'wwsjG',
        '𝐨𝐝𝐢𝐨\x20@\x0a-\x20',
        '1089SAJfoz',
        '𝐢𝐧𝐬𝐮𝐥𝐭𝐚\x20@\x0a-\x20',
        '𝐝𝐚𝐝𝐨\x0a-\x20',
        '𝐩𝐮𝐭𝐭𝐚𝐧𝐚\x20@\x0a-\x20',
        'getName',
        'ZAiBl',
        '𝐁𝐢𝐱𝐛𝐲𝐁𝐨𝐭-𝐌𝐝\x20🔮',
        '4toEJQc',
        '3393410lPLOcF',
        'length',
        'toString',
        '𝐬𝐞𝐭𝐢𝐠\x0a-\x20',
        '𝐦𝐬𝐠/𝐚𝐭𝐭𝐢𝐯𝐢𝐭𝐚\x27\x20@\x0a-\x20',
        'endsWith',
        '120363175463922716@newsletter',
        '@g.us',
        'command',
        '𝐛𝐞𝐥𝐥𝐨/𝐚\x20@\x0a-\x20',
        '𝐥𝐞𝐬𝐛𝐢𝐜𝐚\x20@\x0a-\x20',
        '𝐜𝐫𝐮𝐬𝐡\x0a-\x20',
        'menu',
        'opts',
        'now',
        'help',
        'aqgTp',
        '10972qUMMfT',
        '𝐬𝐭𝐢𝐜𝐤𝐞𝐫\x20/\x20𝐬\x0a-\x20',
        'LmHap',
        'map',
        '𝐭𝐫𝐢𝐬\x0a-\x20',
        '𝐬𝐞𝐠𝐚\x20(\x20𝐧𝐨𝐦𝐞\x20)\x0a-\x20',
        '𝐥𝐞𝐠𝐠𝐢\x20(\x20𝐟𝐨𝐭𝐨\x20)\x0a-\x20',
        'sendMessage',
        '0@s.whatsapp.net',
        '𝐚𝐛𝐛𝐫𝐚𝐜𝐜𝐢𝐚\x20@\x0a-\x20',
        '𝐬𝐜𝐨𝐩𝐚\x20@\x0a-\x20',
        'keys',
        '𝐬𝐡𝐚𝐳𝐚𝐦\x20(\x20𝐚𝐮𝐝𝐢𝐨\x20)\x0a-\x20',
        '𝐝𝐢𝐦𝐦𝐢\x20(\x20𝐢𝐧𝐭𝐞𝐥𝐥𝐢𝐠𝐞𝐧𝐳𝐚\x20𝐚𝐫𝐭𝐢𝐟𝐢𝐜𝐢𝐚𝐥𝐞\x20)\x0a-\x20',
        'chat',
        '𝐠𝐢𝐭𝐜𝐥𝐨𝐧𝐞\x0a-\x20',
        '2092504PprSIF',
        '24HQYqPa',
        'jid',
        '𝐭𝐨𝐠𝐢𝐟\x0a-\x20',
        'PApIp',
        'memoryUsage',
        'tMEMY',
        '𝐫𝐢𝐦𝐮𝐨𝐯𝐢𝐬𝐟𝐨𝐧𝐝𝐨\x20(\x20𝐟𝐨𝐭𝐨\x20)\x0a-\x20',
        '𝐭𝐨𝐩𝐧𝐚𝐳𝐢\x0a-\x20',
        '𝐪𝐫𝐜𝐨𝐝𝐞\x20(\x20𝐭𝐞𝐬𝐭𝐨\x20)\x0a-\x20',
        '𝐢𝐝\x20(𝐠𝐫𝐮𝐩𝐩𝐨)\x0a-\x20',
        '𝐌𝐞𝐧𝐮\x20𝐆𝐫𝐮𝐩𝐩𝐨',
        '7070074yeAdRp',
        'tags',
        '𝐭𝐭𝐩\x0a-\x20',
        'parseMention',
        'buffer',
        '8026851IFSoji',
        'filter',
        'padStart',
        '𝐝𝐢𝐭𝐚𝐥𝐢𝐧𝐨\x20(\x20𝐧𝐨𝐦𝐞\x20)\x0a-\x20',
        'KjWso',
        '𝐠𝐚𝐲\x20@\x0a-\x20',
        'nomedelbot',
        'floor',
        '𝐫𝐢𝐦𝐮𝐨𝐯𝐢𝐬𝐟𝐨𝐧𝐝𝐨\x0a-\x20',
        '𝐬𝐩𝐨𝐬𝐚𝐦𝐢\x0a-\x20',
        '𝐜𝐨𝐧𝐭𝐚𝐩𝐚𝐫𝐨𝐥𝐞\x20(\x20𝐭𝐞𝐬𝐭𝐨\x20)\x0a-\x20'
    ];
    _0x30fe = function () {
        return _0x8a023f;
    };
    return _0x30fe();
}
import _0x40879e from 'human-readable';
import _0x1440e7 from '@whiskeysockets/baileys';
import _0x3ace74 from 'fs';
function _0x266e(_0xd0ff2, _0x2de91e) {
    const _0x170aaf = _0x30fe();
    return _0x266e = function (_0x496f57, _0xaf65db) {
        _0x496f57 = _0x496f57 - (-0x2 * -0xe68 + 0xb4c + -0x26c3);
        let _0x9a4ddf = _0x170aaf[_0x496f57];
        return _0x9a4ddf;
    }, _0x266e(_0xd0ff2, _0x2de91e);
}
import { performance } from 'perf_hooks';
let handler = async (_0x316f52, {
    conn: _0x4a2566,
    usedPrefix: _0x238280
}) => {
    const _0x109283 = _0x266e, _0x28bf07 = {
            'LmHap': function (_0x4f7ef4, _0x287092) {
                return _0x4f7ef4 * _0x287092;
            },
            'ZAiBl': function (_0x16f472, _0x54e7b7) {
                return _0x16f472(_0x54e7b7);
            },
            'aqgTp': function (_0xb8e06b, _0x5b6010) {
                return _0xb8e06b - _0x5b6010;
            },
            'KjWso': _0x109283(0x1a4),
            'wwsjG': 'Halo',
            'IdhoN': _0x109283(0x171),
            'tMEMY': _0x109283(0x191)
        };
    let _0x455740 = _0x28bf07[_0x109283(0x19e)](process[_0x109283(0x16f)](), -0x743 + 0x240e + -0x18e3), _0x24148d = _0x28bf07[_0x109283(0x188)](clockString, _0x455740), _0x112379 = Object[_0x109283(0x1a7)](global['db']['data']['users'])[_0x109283(0x18c)];
    const _0xa3aedc = Object['entries'](_0x4a2566[_0x109283(0x16d)])[_0x109283(0x163)](([_0x137bfd, _0x24e7eb]) => _0x137bfd && _0x24e7eb[_0x109283(0x176)]), _0x40a16c = _0xa3aedc[_0x109283(0x163)](([_0x19dea3]) => _0x19dea3[_0x109283(0x190)](_0x109283(0x192))), _0x43a1c2 = _0xa3aedc[_0x109283(0x163)](([_0xf25928]) => _0xf25928[_0x109283(0x190)]('@g.us')), _0xc0ed11 = process[_0x109283(0x1b1)](), {restrict: _0x4fb137} = global['db']['data'][_0x109283(0x17c)][_0x4a2566['user'][_0x109283(0x1ae)]] || {}, {autoread: _0x1704a4} = global[_0x109283(0x198)];
    let _0x49ffdf = performance[_0x109283(0x199)](), _0x2800c5 = performance['now'](), _0x52c6e0 = _0x28bf07[_0x109283(0x19b)](_0x2800c5, _0x49ffdf), _0x38c718 = await _0x4a2566[_0x109283(0x187)](_0x316f52['sender']), _0x12abbd = {
            'key': {
                'participants': _0x28bf07[_0x109283(0x166)],
                'fromMe': ![],
                'id': _0x28bf07[_0x109283(0x181)]
            },
            'message': {
                'locationMessage': {
                    'name': _0x109283(0x15c),
                    'jpegThumbnail': await (await _0x28bf07[_0x109283(0x188)](fetch, _0x28bf07['IdhoN']))[_0x109283(0x161)](),
                    'vcard': 'BEGIN:VCARD\x0aVERSION:3.0\x0aN:;Unlimited;;;\x0aFN:Unlimited\x0aORG:Unlimited\x0aTITLE:\x0aitem1.TEL;waid=19709001746:+1\x20(970)\x20900-1746\x0aitem1.X-ABLabel:Unlimited\x0aX-WA-BIZ-DESCRIPTION:ofc\x0aX-WA-BIZ-NAME:Unlimited\x0aEND:VCARD'
                }
            },
            'participant': _0x28bf07[_0x109283(0x166)]
        }, _0x52ca99 = ('\x0a──────────────\x0a-\x20' + _0x238280 + _0x109283(0x1a9) + _0x238280 + '𝐛𝐚𝐫𝐝\x20(\x20𝐢𝐧𝐭𝐞𝐥𝐥𝐢𝐠𝐞𝐧𝐳𝐚\x20𝐚𝐫𝐭𝐢𝐟𝐢𝐜𝐢𝐚𝐥𝐞\x20)\x0a-\x20' + _0x238280 + '𝐩𝐥𝐚𝐲\x20(\x20𝐜𝐚𝐧𝐳𝐨𝐧𝐞\x20+\x20𝐚𝐫𝐭𝐢𝐬𝐭𝐚\x20)\x20\x0a-\x20' + _0x238280 + _0x109283(0x16e) + _0x238280 + _0x109283(0x1a8) + _0x238280 + _0x109283(0x173) + _0x238280 + '𝐡𝐝\x20(\x20𝐟𝐨𝐭𝐨\x20)\x0a-\x20' + _0x238280 + _0x109283(0x1a2) + _0x238280 + _0x109283(0x1b3) + _0x238280 + _0x109283(0x1a1) + _0x238280 + _0x109283(0x165) + _0x238280 + '𝐢𝐧𝐬𝐮𝐥𝐭𝐚\x20(\x20𝐧𝐨𝐦𝐞\x20)\x0a-\x20' + _0x238280 + _0x109283(0x15a) + _0x238280 + _0x109283(0x178) + _0x238280 + '𝐬𝐭𝐲𝐥𝐞𝐭𝐞𝐱𝐭\x20(\x20𝐭𝐞𝐬𝐭𝐨\x20)\x0a-\x20' + _0x238280 + '𝐜𝐚𝐥𝐜\x20(\x20𝟏+𝟏\x20)\x0a-\x20' + _0x238280 + _0x109283(0x18f) + _0x238280 + _0x109283(0x16c) + _0x238280 + _0x109283(0x194) + _0x238280 + _0x109283(0x167) + _0x238280 + _0x109283(0x186) + _0x238280 + _0x109283(0x195) + _0x238280 + _0x109283(0x184) + _0x238280 + _0x109283(0x1a6) + _0x238280 + _0x109283(0x1a5) + _0x238280 + _0x109283(0x182) + _0x238280 + '𝐚𝐦𝐨𝐫𝐞\x20@\x0a-\x20' + _0x238280 + _0x109283(0x17d) + _0x238280 + _0x109283(0x15b) + _0x238280 + _0x109283(0x1ab) + _0x238280 + _0x109283(0x17a) + _0x238280 + _0x109283(0x18e) + _0x238280 + _0x109283(0x179) + _0x238280 + _0x109283(0x1a0) + _0x238280 + _0x109283(0x16b) + _0x238280 + _0x109283(0x196) + _0x238280 + '𝐭𝐨𝐩𝐠𝐚𝐲𝐬\x0a-\x20' + _0x238280 + _0x109283(0x159) + _0x238280 + _0x109283(0x15f) + _0x238280 + _0x109283(0x185) + _0x238280 + _0x109283(0x19d) + _0x238280 + _0x109283(0x16a) + _0x238280 + '𝐭𝐨𝐯𝐢𝐝𝐞𝐨\x0a-\x20' + _0x238280 + _0x109283(0x1af) + _0x238280 + _0x109283(0x17b))['trim'](), _0x18f634 = global['db'][_0x109283(0x17f)][_0x109283(0x168)] || _0x109283(0x189);
    _0x4a2566[_0x109283(0x1a3)](_0x316f52[_0x109283(0x1aa)], {
        'text': _0x52ca99,
        'contextInfo': {
            'mentionedJid': _0x4a2566[_0x109283(0x160)](wm),
            'forwardingScore': 0x1,
            'isForwarded': !![],
            'forwardedNewsletterMessageInfo': {
                'newsletterJid': _0x28bf07[_0x109283(0x1b2)],
                'serverMessageId': '',
                'newsletterName': '' + _0x18f634
            }
        }
    }, { 'quoted': _0x12abbd });
};
handler[_0x5f520b(0x19a)] = [_0x5f520b(0x197)], handler[_0x5f520b(0x15e)] = ['menu'], handler[_0x5f520b(0x193)] = /^(menugruppo|gruppo)$/i;
export default handler;
function clockString(_0x5376bb) {
    const _0x2af831 = _0x5f520b, _0x480ad4 = {
            'SqErr': function (_0x4d81a8, _0x791cf8) {
                return _0x4d81a8 / _0x791cf8;
            },
            'PApIp': function (_0x567ab0, _0x349665) {
                return _0x567ab0 % _0x349665;
            },
            'cBuYL': function (_0x23c0c8, _0x3b1513) {
                return _0x23c0c8 / _0x3b1513;
            },
            'ARHsG': function (_0x1eca41, _0x42000a) {
                return _0x1eca41 % _0x42000a;
            }
        };
    let _0x14ce08 = Math[_0x2af831(0x169)](_0x480ad4[_0x2af831(0x172)](_0x5376bb, 0x1a * -0x2ecd + -0x3987a * -0x1e + -0x302efa)), _0x11e6bc = _0x480ad4[_0x2af831(0x1b0)](Math[_0x2af831(0x169)](_0x480ad4[_0x2af831(0x170)](_0x5376bb, -0xaf98 + 0x1 * -0x14966 + 0x2e35e)), -0x62c + -0x2282 * -0x1 + -0x1c1a * 0x1), _0xaff805 = _0x480ad4[_0x2af831(0x175)](Math['floor'](_0x5376bb / (0x5 * -0x557 + -0x19b6 + 0x455 * 0xd)), 0x581 * -0x3 + 0x2371 * 0x1 + -0x12b2);
    return console['log']({
        'ms': _0x5376bb,
        'h': _0x14ce08,
        'm': _0x11e6bc,
        's': _0xaff805
    }), [
        _0x14ce08,
        _0x11e6bc,
        _0xaff805
    ][_0x2af831(0x19f)](_0x421c43 => _0x421c43[_0x2af831(0x18d)]()[_0x2af831(0x164)](0x134e + -0x1548 + 0x1 * 0x1fc, -0xce + 0xe * -0x166 + 0x1462))['join'](':');
}