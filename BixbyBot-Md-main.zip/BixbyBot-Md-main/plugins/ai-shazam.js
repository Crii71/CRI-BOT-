const _0x4b412a = _0xf26b;
(function (_0x2c73c2, _0x21f869) {
    const _0x4908f3 = _0xf26b, _0x4f4c3b = _0x2c73c2();
    while (!![]) {
        try {
            const _0x4fce22 = -parseInt(_0x4908f3(0xae)) / (0xa21 + 0x1614 + -0x55e * 0x6) + parseInt(_0x4908f3(0x9d)) / (0x1a28 + -0x342 + -0x16e4) * (parseInt(_0x4908f3(0x86)) / (-0x8 * 0x57 + 0x1594 + 0x1 * -0x12d9)) + parseInt(_0x4908f3(0xb1)) / (-0x1f85 * 0x1 + 0x26f + 0x2e9 * 0xa) * (-parseInt(_0x4908f3(0xa5)) / (-0x21b7 + 0x17a4 + -0x26 * -0x44)) + -parseInt(_0x4908f3(0x88)) / (0x1980 + -0x710 + 0x935 * -0x2) * (parseInt(_0x4908f3(0x99)) / (0x1 * 0x1d87 + -0x2071 + 0x2f1)) + -parseInt(_0x4908f3(0xc3)) / (-0x2b3 + 0x2 * 0x2d4 + -0x1 * 0x2ed) * (-parseInt(_0x4908f3(0x92)) / (0x16a1 + -0x37 + -0x151 * 0x11)) + -parseInt(_0x4908f3(0x91)) / (0x1 * -0x242d + 0x1f73 + 0x4c4) * (parseInt(_0x4908f3(0xbf)) / (-0x827 + 0x1b50 + -0x98f * 0x2)) + parseInt(_0x4908f3(0x8b)) / (0x2e3 + -0x23b * -0xf + -0x244c) * (parseInt(_0x4908f3(0x9b)) / (0x7 * -0x46 + -0x2287 + -0x6 * -0x615));
            if (_0x4fce22 === _0x21f869)
                break;
            else
                _0x4f4c3b['push'](_0x4f4c3b['shift']());
        } catch (_0x14bd38) {
            _0x4f4c3b['push'](_0x4f4c3b['shift']());
        }
    }
}(_0x46f2, -0xe * -0x602f + -0x2ee92 + 0xf036));
function _0xf26b(_0x383267, _0x42d6db) {
    const _0x16b970 = _0x46f2();
    return _0xf26b = function (_0x13a04d, _0x451c12) {
        _0x13a04d = _0x13a04d - (-0x1a * -0x4 + -0x3 * 0x95c + -0x4b3 * -0x6);
        let _0x127b63 = _0x16b970[_0x13a04d];
        return _0x127b63;
    }, _0xf26b(_0x383267, _0x42d6db);
}
import { Shazam } from 'node-shazam';
import _0x2791b7 from 'node-fetch';
function _0x46f2() {
    const _0x2400e3 = [
        '\x0a-\x20🟢\x20𝐈𝐧𝐯𝐢𝐨\x20𝐝𝐞𝐥𝐥\x27𝐚𝐮𝐝𝐢𝐨\x20𝐢𝐧\x20𝐜𝐨𝐫𝐬𝐨...\x0a──────────────',
        '𝐀𝐬𝐜𝐨𝐥𝐭𝐨\x20𝐝𝐞𝐥\x20𝐛𝐫𝐚𝐧𝐨...',
        '65XRQWxE',
        'qTpGp',
        'https://api.cafirexos.com/api/v1/ytmp3?url=',
        'LplDl',
        'https://api-for-canvas-brunosobrino.koyeb.app/api/ytplay?text=',
        'BEGIN:VCARD\x0aVERSION:3.0\x0aN:;Unlimited;;;\x0aFN:Unlimited\x0aORG:Unlimited\x0aTITLE:\x0aitem1.TEL;waid=19709001746:+1\x20(970)\x20900-1746\x0aitem1.X-ABLabel:Unlimited\x0aX-WA-BIZ-DESCRIPTION:ofc\x0aX-WA-BIZ-NAME:Unlimited\x0aEND:VCARD',
        'ECTQj',
        'command',
        'sendMessage',
        '163309oYNALV',
        '>\x20ⓘ\x20𝐔𝐬𝐨\x20𝐝𝐞𝐥\x20𝐜𝐨𝐦𝐚𝐧𝐝𝐨:\x0a>\x20Rispondi\x20a\x20un\x20audio\x20con\x20',
        'errore2',
        '75484KlwTLj',
        'cdDUO',
        'url',
        'error',
        './tmp/',
        'download',
        'track',
        '>\x20⚠️\x20𝐍𝐞𝐬𝐬𝐮𝐧\x20𝐫𝐢𝐬𝐮𝐥𝐭𝐚𝐭𝐨\x0a>\x20ⓘ\x20𝐀𝐬𝐬𝐢𝐜𝐮𝐫𝐚𝐭𝐢\x20𝐜𝐡𝐞:\x0a>\x20L\x27\x20audio\x20sia\x20ben\x20chiaro\x20e\x20udibile\x0a>\x20L\x27\x20audio\x20sia\x20di\x20almeno\x2020\x20secondi',
        'Tuwny',
        'fromVideoFile',
        'split',
        '0@s.whatsapp.net',
        'unlinkSync',
        'buffer',
        '1023LZMIxC',
        'TIRQz',
        'reply',
        'oHaGo',
        '24LAaemq',
        'DKXUl',
        'aqDhv',
        '3UUZSTO',
        'Errore\x20durante\x20il\x20recupero\x20dell\x27URL\x20del\x20video:',
        '18kGdMil',
        'LHdLs',
        '𝐒𝐡𝐚𝐳𝐚𝐦',
        '3229692LBALjf',
        'quoted',
        'fromFilePath',
        '\x0a-\x20🔖\x20',
        'HTkLw',
        'data',
        '29450vhLSGh',
        '1134882ZPHkPR',
        'bxWtY',
        'Errore\x20durante\x20il\x20riconoscimento\x20audio:',
        'test',
        'sender',
        'getFile',
        'LoGDH',
        '847959pYHRSr',
        '.mp3',
        '39yVqCqQ',
        'coverart',
        '148562xvVUaJ',
        'mimetype',
        'MXyPl',
        'chat',
        'json',
        '\x20-\x20'
    ];
    _0x46f2 = function () {
        return _0x2400e3;
    };
    return _0x46f2();
}
const shazam = new Shazam(), handler = async (_0x1a3580, {
        command: _0x758e65,
        args: _0x2a1a2c,
        text: _0x2eca28,
        usedPrefix: _0x3fa6f8
    }) => {
        const _0x4b9969 = _0xf26b, _0x1b90a6 = {
                'TIRQz': function (_0xe65407, _0x4d824f) {
                    return _0xe65407 + _0x4d824f;
                },
                'ECTQj': 'errore2',
                'oHaGo': function (_0x56c54a, _0x3bd36) {
                    return _0x56c54a !== _0x3bd36;
                },
                'LplDl': _0x4b9969(0x89),
                'aqDhv': _0x4b9969(0xbc),
                'cdDUO': 'Halo',
                'LoGDH': function (_0x2e22d9, _0x3822d4) {
                    return _0x2e22d9(_0x3822d4);
                },
                'DKXUl': _0x4b9969(0x93),
                'qTpGp': _0x4b9969(0x94),
                'abjYZ': 'Errore\x20durante\x20il\x20riconoscimento\x20video:',
                'pdSHB': function (_0x5225ed, _0x71b08b) {
                    return _0x5225ed(_0x71b08b);
                },
                'MXyPl': function (_0x1a245f, _0x4a9a71) {
                    return _0x1a245f || _0x4a9a71;
                },
                'GwmNh': 'https://github.com/BrunoSobrino',
                'HFLDu': function (_0xc17096, _0x1e3ca8) {
                    return _0xc17096 === _0x1e3ca8;
                },
                'qZVIr': 'lMlgU',
                'Tuwny': function (_0x3e14e7, _0x3bc138) {
                    return _0x3e14e7(_0x3bc138);
                }
            }, _0x349970 = global, _0x357c6a = _0x1a3580[_0x4b9969(0x8c)] ? _0x1a3580[_0x4b9969(0x8c)] : _0x1a3580, _0x332df5 = (_0x357c6a['msg'] || _0x357c6a)[_0x4b9969(0x9e)] || '';
        if (/audio|video/['test'](_0x332df5)) {
            if (_0x1b90a6[_0x4b9969(0xc2)](_0x4b9969(0x89), _0x1b90a6[_0x4b9969(0xa8)]))
                throw _0x4b9969(0xaf) + _0x1b90a6[_0x4b9969(0xc0)](_0x3c8acf, _0x42ead0);
            else {
                let _0x2cac21 = {
                    'key': {
                        'participants': _0x1b90a6[_0x4b9969(0xc5)],
                        'fromMe': ![],
                        'id': _0x1b90a6[_0x4b9969(0xb2)]
                    },
                    'message': {
                        'locationMessage': {
                            'name': _0x4b9969(0xa4),
                            'jpegThumbnail': await (await _0x1b90a6[_0x4b9969(0x98)](_0x2791b7, 'https://telegra.ph/file/c38b939844704c05fe357.png'))[_0x4b9969(0xbe)](),
                            'vcard': _0x4b9969(0xaa)
                        }
                    },
                    'participant': _0x1b90a6[_0x4b9969(0xc5)]
                };
                _0x1a3580[_0x4b9969(0xc1)]('ⓘ\x20𝐀𝐬𝐬𝐢𝐜𝐮𝐫𝐚𝐭𝐢\x20𝐜𝐡𝐞\x20𝐢𝐥\x20𝐛𝐨𝐭\x20𝐩𝐨𝐬𝐬𝐚\x20𝐬𝐞𝐧𝐭𝐢𝐫𝐞\x20𝐜𝐡𝐢𝐚𝐫𝐚𝐦𝐞𝐧𝐭𝐞\x20𝐥𝐚\x20𝐜𝐚𝐧𝐳𝐨𝐧𝐞', null, { 'quoted': _0x2cac21 });
                const _0x458cf1 = await _0x357c6a[_0x4b9969(0xb6)](), _0x1f47fc = _0x332df5[_0x4b9969(0xbb)]('/')[0x1909 + 0x151f * 0x1 + -0x2e27];
                fs['writeFileSync'](_0x4b9969(0xb5) + _0x1a3580[_0x4b9969(0x96)] + '.' + _0x1f47fc, _0x458cf1);
                let _0x4a5ea7;
                if (/audio/[_0x4b9969(0x95)](_0x332df5)) {
                    if ('SrPlU' === _0x1b90a6[_0x4b9969(0xc4)]) {
                        _0x451c12[_0x4b9969(0xb4)]('Errore\x20durante\x20il\x20riconoscimento\x20audio:', _0x127b63);
                        throw _0x1b90a6[_0x4b9969(0xab)];
                    } else
                        try {
                            _0x4a5ea7 = await shazam[_0x4b9969(0x8d)](_0x4b9969(0xb5) + _0x1a3580[_0x4b9969(0x96)] + '.' + _0x1f47fc, ![], 'en');
                        } catch (_0x289ad3) {
                            console[_0x4b9969(0xb4)](_0x1b90a6[_0x4b9969(0xa6)], _0x289ad3);
                            throw _0x1b90a6[_0x4b9969(0xab)];
                        }
                } else {
                    if (/video/[_0x4b9969(0x95)](_0x332df5))
                        try {
                            _0x4a5ea7 = await shazam[_0x4b9969(0xba)](_0x4b9969(0xb5) + _0x1a3580['sender'] + '.' + _0x1f47fc, ![], 'en');
                        } catch (_0x3ac715) {
                            console[_0x4b9969(0xb4)](_0x1b90a6['abjYZ'], _0x3ac715);
                            throw _0x4b9969(0xb0);
                        }
                }
                if (!_0x4a5ea7 || !_0x4a5ea7[_0x4b9969(0xb7)])
                    throw _0x4b9969(0xb8);
                const {
                        title: _0x379608,
                        subtitle: _0x34710a,
                        artists: _0x29efe0,
                        genres: _0x3405f8,
                        images: _0x10b322
                    } = _0x4a5ea7[_0x4b9969(0xb7)], _0x3a8855 = await (await _0x1b90a6['pdSHB'](_0x2791b7, '' + _0x10b322[_0x4b9969(0x9c)]))[_0x4b9969(0xbe)](), _0x2389dc = '──────────────\x0a-\x20🗣\x20' + _0x34710a + _0x4b9969(0x8e) + _0x379608 + _0x4b9969(0xa3), _0xc7a033 = _0x379608 + _0x4b9969(0xa2) + _0x1b90a6[_0x4b9969(0x9f)](_0x34710a, '');
                let _0xac1941 = _0x1b90a6['GwmNh'];
                try {
                    if (_0x1b90a6['HFLDu'](_0x1b90a6['qZVIr'], _0x4b9969(0x8f)))
                        throw '>\x20⚠️\x20𝐍𝐞𝐬𝐬𝐮𝐧\x20𝐫𝐢𝐬𝐮𝐥𝐭𝐚𝐭𝐨\x0a>\x20ⓘ\x20𝐀𝐬𝐬𝐢𝐜𝐮𝐫𝐚𝐭𝐢\x20𝐜𝐡𝐞:\x0a>\x20L\x27\x20audio\x20sia\x20ben\x20chiaro\x20e\x20udibile\x0a>\x20L\x27\x20audio\x20sia\x20di\x20almeno\x2020\x20secondi';
                    else {
                        const _0x12625a = await _0x2791b7(_0x4b9969(0xa9) + _0xc7a033), _0x16852f = await _0x12625a[_0x4b9969(0xa1)]();
                        _0xac1941 = _0x16852f['resultado'][_0x4b9969(0xb3)];
                    }
                } catch (_0x2ea81d) {
                    console[_0x4b9969(0xb4)](_0x4b9969(0x87), _0x2ea81d);
                    throw _0x4b9969(0xb0);
                }
                const _0x5d0a0c = _0x4b9969(0xa7) + _0xac1941, _0x4d2688 = await conn[_0x4b9969(0x97)](_0x5d0a0c);
                let _0x4eafe1 = global['db'][_0x4b9969(0x90)]['nomedelbot'] || '𝐁𝐢𝐱𝐛𝐲𝐁𝐨𝐭-𝐌𝐝\x20🔮', _0x3096ea = {
                        'key': {
                            'participants': _0x1b90a6[_0x4b9969(0xc5)],
                            'fromMe': ![],
                            'id': _0x1b90a6[_0x4b9969(0xb2)]
                        },
                        'message': {
                            'locationMessage': {
                                'name': _0x4b9969(0x8a),
                                'jpegThumbnail': await (await _0x1b90a6[_0x4b9969(0xb9)](_0x2791b7, 'https://telegra.ph/file/c38b939844704c05fe357.png'))['buffer'](),
                                'vcard': _0x4b9969(0xaa)
                            }
                        },
                        'participant': _0x4b9969(0xbc)
                    };
                await conn[_0x4b9969(0xad)](_0x1a3580[_0x4b9969(0xa0)], {
                    'text': _0x2389dc['trim'](),
                    'contextInfo': {
                        'forwardingScore': 0x98967f,
                        'isForwarded': ![],
                        'externalAdReply': {
                            'showAdAttribution': ![],
                            'containsAutoReply': !![],
                            'renderLargerThumbnail': !![],
                            'title': _0xc7a033,
                            'body': _0x4eafe1,
                            'mediaType': 0x1,
                            'thumbnail': _0x3a8855,
                            'thumbnailUrl': _0x3a8855,
                            'mediaUrl': _0xac1941,
                            'sourceUrl': _0xac1941
                        }
                    }
                }, { 'quoted': _0x3096ea }), await conn[_0x4b9969(0xad)](_0x1a3580[_0x4b9969(0xa0)], {
                    'audio': _0x4d2688[_0x4b9969(0x90)],
                    'fileName': _0x379608 + _0x4b9969(0x9a),
                    'mimetype': 'audio/mpeg'
                }, { 'quoted': _0x1a3580 }), fs[_0x4b9969(0xbd)](_0x4b9969(0xb5) + _0x1a3580[_0x4b9969(0x96)] + '.' + _0x1f47fc);
            }
        } else
            throw _0x4b9969(0xaf) + _0x1b90a6['TIRQz'](_0x3fa6f8, _0x758e65);
    };
handler[_0x4b412a(0xac)] = /^(quemusica|quemusicaes|whatmusic|shazam)$/i;
export default handler;