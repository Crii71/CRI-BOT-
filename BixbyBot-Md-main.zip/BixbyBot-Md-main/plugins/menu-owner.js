const _0x2972a0 = _0x2081;
(function (_0x14b387, _0x629d87) {
    const _0x4fb991 = _0x2081, _0x25c42c = _0x14b387();
    while (!![]) {
        try {
            const _0x2913a8 = -parseInt(_0x4fb991(0x165)) / (-0x1be2 + -0xd07 + 0x1475 * 0x2) * (-parseInt(_0x4fb991(0x16b)) / (0x397 * -0x8 + 0x1f * -0x8c + -0x16d7 * -0x2)) + parseInt(_0x4fb991(0x156)) / (-0x1 * 0x925 + 0x1031 + 0x1 * -0x709) * (-parseInt(_0x4fb991(0x16f)) / (0x1483 + 0x4c1 + -0x1940)) + parseInt(_0x4fb991(0x142)) / (0x152f + -0xd85 * 0x1 + -0x7a5) + parseInt(_0x4fb991(0x151)) / (0x1212 + -0xd6 * -0x27 + -0x32a6) * (-parseInt(_0x4fb991(0x170)) / (-0x1d66 + -0x8ed * 0x1 + 0x2 * 0x132d)) + parseInt(_0x4fb991(0x161)) / (-0x1f8b + -0x1f * 0x74 + 0x2d9f) + parseInt(_0x4fb991(0x13f)) / (-0x2405 + -0x10e + -0x1db * -0x14) * (-parseInt(_0x4fb991(0x148)) / (-0x56 * 0x44 + -0x17e6 + 0x1764 * 0x2)) + parseInt(_0x4fb991(0x17b)) / (-0x2 * -0x5e + 0x18f4 + 0x1 * -0x19a5);
            if (_0x2913a8 === _0x629d87)
                break;
            else
                _0x25c42c['push'](_0x25c42c['shift']());
        } catch (_0x4a79c7) {
            _0x25c42c['push'](_0x25c42c['shift']());
        }
    }
}(_0x295b, -0xb * 0xcf09 + -0x375cf + 0x143ec5));
import _0x390774 from 'os';
function _0x2081(_0x426879, _0x14e1be) {
    const _0x3e0bdf = _0x295b();
    return _0x2081 = function (_0x45b661, _0x18f390) {
        _0x45b661 = _0x45b661 - (0x1059 + 0x165d + 0x1 * -0x257e);
        let _0x53e94e = _0x3e0bdf[_0x45b661];
        return _0x53e94e;
    }, _0x2081(_0x426879, _0x14e1be);
}
function _0x295b() {
    const _0x9ffa2c = [
        '𝐨𝐮𝐭\x0a-\x20',
        'tags',
        'command',
        '𝐩𝐮𝐥𝐢𝐳𝐢𝐚\x20(+)\x0a-\x20',
        'buffer',
        '@g.us',
        '𝐚𝐳𝐳𝐞𝐫𝐚\x20@\x0a-\x20',
        'settings',
        'pLKRv',
        '𝐢𝐦𝐩𝐨𝐬𝐭𝐚𝐧𝐨𝐦𝐞\x0a-\x20',
        '\x0a────────────────\x0a>\x20𝐏𝐚𝐧𝐧𝐞𝐥𝐥𝐨\x20𝐝𝐢\x20𝐜𝐨𝐧𝐭𝐫𝐨𝐥𝐥𝐨\x20𝐌𝐨𝐝𝐞𝐫𝐚𝐭𝐨𝐫𝐞\x0a────────────────\x0a-\x20',
        '1279791krggci',
        'map',
        '𝐫𝐞𝐬𝐞𝐭𝐭𝐚𝐩𝐫𝐞𝐟𝐢𝐬𝐬𝐨\x0a-\x20',
        '2920395yvqHrT',
        'isChats',
        '𝐚𝐠𝐠𝐢𝐮𝐧𝐠𝐢\x20(𝐧𝐮𝐦.\x20𝐦𝐞𝐬𝐬𝐚𝐠𝐠𝐢)\x20@\x0a-\x20',
        'log',
        'entries',
        'fRkLB',
        '40ghssnw',
        'uptime',
        '0@s.whatsapp.net',
        'Gymwe',
        'IpObQ',
        'user',
        '𝐬𝐞𝐭𝐩𝐩\x20(\x20𝐢𝐦𝐦𝐚𝐠𝐢𝐧𝐞\x20)\x0a-\x20',
        'opts',
        './no.png',
        '3572178cpVSxA',
        'https://telegra.ph/file/2f38b3fd9cfba5935b496.jpg',
        '𝐝𝐩\x20(𝐩𝐥𝐮𝐠𝐢𝐧)\x0a-\x20',
        'PBOGy',
        '𝐛𝐥𝐨𝐜𝐤𝐮𝐬𝐞𝐫\x20@\x0a-\x20',
        '4137OesmCc',
        'FZtnx',
        'keys',
        '𝐠𝐨𝐝𝐦𝐨𝐝𝐞\x20{𝐚𝐮𝐭𝐨𝐚𝐝𝐦𝐢𝐧}\x0a-\x20',
        'toString',
        'parseMention',
        '𝐠𝐞𝐬𝐭𝐢𝐬𝐜𝐢\x20@\x0a-\x20',
        'memoryUsage',
        '120363175463922716@newsletter',
        'data',
        'length',
        '432136SwNrsv',
        'filter',
        '𝐩𝐫𝐞𝐟𝐢𝐬𝐬𝐨\x20(?)\x0a-\x20',
        'floor',
        '33386qXPswQ',
        'users',
        '𝐫𝐞𝐬𝐞𝐭𝐠𝐫𝐮𝐩𝐩𝐢\x20@\x0a-\x20',
        '𝐮𝐧𝐛𝐚𝐧𝐮𝐬𝐞𝐫\x20@\x0a-\x20',
        '𝐌𝐞𝐧𝐮\x20𝐎𝐰𝐧𝐞𝐫',
        'getName',
        '38hOXnZe',
        'endsWith',
        'chats',
        '𝐠𝐞𝐭𝐩𝐥𝐮𝐠𝐢𝐧\x0a-\x20',
        '1228FeYNen',
        '7yVVPEt',
        '𝐮𝐧𝐛𝐥𝐨𝐜𝐤𝐮𝐬𝐞𝐫\x20@\x0a-\x20',
        'IJOSu',
        '𝐣𝐨𝐢𝐧\x20+\x20𝐥𝐢𝐧𝐤\x0a-\x20',
        'joqRC',
        'jid',
        'HhDkh',
        'yhBxL',
        'sender',
        'join',
        'menu',
        '9153023DoozXX'
    ];
    _0x295b = function () {
        return _0x9ffa2c;
    };
    return _0x295b();
}
import _0x50ff82 from 'util';
import _0x87936 from 'human-readable';
import _0x3d7257 from '@whiskeysockets/baileys';
import _0x6f6605 from 'fs';
import { performance } from 'perf_hooks';
let handler = async (_0x1ece27, {
    conn: _0x4d8805,
    usedPrefix: _0x2b0a49
}) => {
    const _0x357b5a = _0x2081, _0x274e15 = {
            'PBOGy': function (_0x5ea127, _0x83cca3) {
                return _0x5ea127 * _0x83cca3;
            },
            'yhBxL': function (_0x1312b8, _0x1ac94c) {
                return _0x1312b8(_0x1ac94c);
            },
            'FZtnx': _0x357b5a(0x150),
            'fRkLB': function (_0x306279, _0x273188) {
                return _0x306279 - _0x273188;
            },
            'joqRC': _0x357b5a(0x14a),
            'IJOSu': 'Halo',
            'HhDkh': _0x357b5a(0x152),
            'pLKRv': _0x357b5a(0x15e)
        };
    let _0x3f1cc6 = _0x274e15[_0x357b5a(0x154)](process[_0x357b5a(0x149)](), -0x11d * -0x23 + -0x2617 + 0x1 * 0x308), _0x5b36cf = _0x274e15[_0x357b5a(0x177)](clockString, _0x3f1cc6), _0x484772 = Object[_0x357b5a(0x158)](global['db'][_0x357b5a(0x15f)][_0x357b5a(0x166)])[_0x357b5a(0x160)];
    const _0x253d7b = Object[_0x357b5a(0x146)](_0x4d8805[_0x357b5a(0x16d)])[_0x357b5a(0x162)](([_0x305c9a, _0x31a8c6]) => _0x305c9a && _0x31a8c6[_0x357b5a(0x143)]), _0x1549b5 = _0x253d7b[_0x357b5a(0x162)](([_0x557c43]) => _0x557c43[_0x357b5a(0x16c)]('@g.us')), _0xe81301 = _0x253d7b['filter'](([_0x3fc8a2]) => _0x3fc8a2['endsWith'](_0x357b5a(0x139))), _0x47cf9f = process[_0x357b5a(0x15d)](), {restrict: _0x437466} = global['db']['data'][_0x357b5a(0x13b)][_0x4d8805[_0x357b5a(0x14d)][_0x357b5a(0x175)]] || {}, {autoread: _0x16b877} = global[_0x357b5a(0x14f)], _0x118607 = _0x274e15[_0x357b5a(0x157)];
    let _0x3a02b0 = performance['now'](), _0x42b386 = performance['now'](), _0x1f666c = _0x274e15[_0x357b5a(0x147)](_0x42b386, _0x3a02b0), _0x28dfc9 = await _0x4d8805[_0x357b5a(0x16a)](_0x1ece27[_0x357b5a(0x178)]), _0x2d215f = {
            'key': {
                'participants': _0x274e15[_0x357b5a(0x174)],
                'fromMe': ![],
                'id': _0x274e15[_0x357b5a(0x172)]
            },
            'message': {
                'locationMessage': {
                    'name': _0x357b5a(0x169),
                    'jpegThumbnail': await (await fetch(_0x274e15[_0x357b5a(0x176)]))[_0x357b5a(0x138)](),
                    'vcard': 'BEGIN:VCARD\x0aVERSION:3.0\x0aN:;Unlimited;;;\x0aFN:Unlimited\x0aORG:Unlimited\x0aTITLE:\x0aitem1.TEL;waid=19709001746:+1\x20(970)\x20900-1746\x0aitem1.X-ABLabel:Unlimited\x0aX-WA-BIZ-DESCRIPTION:ofc\x0aX-WA-BIZ-NAME:Unlimited\x0aEND:VCARD'
                }
            },
            'participant': _0x274e15[_0x357b5a(0x174)]
        }, _0x3f08c2 = (_0x357b5a(0x13e) + _0x2b0a49 + _0x357b5a(0x13d) + _0x2b0a49 + '𝐫𝐞𝐬𝐞𝐭𝐭𝐚𝐧𝐨𝐦𝐞\x0a-\x20' + _0x2b0a49 + _0x357b5a(0x15c) + _0x2b0a49 + '𝐬𝐞𝐭𝐠𝐫𝐮𝐩𝐩𝐢\x0a-\x20' + _0x2b0a49 + '𝐚𝐠𝐠𝐢𝐮𝐧𝐠𝐢𝐠𝐫𝐮𝐩𝐩𝐢\x20@\x0a-\x20' + _0x2b0a49 + _0x357b5a(0x167) + _0x2b0a49 + _0x357b5a(0x14e) + _0x2b0a49 + '𝐛𝐚𝐧𝐮𝐬𝐞𝐫\x20@\x0a-\x20' + _0x2b0a49 + _0x357b5a(0x168) + _0x2b0a49 + _0x357b5a(0x155) + _0x2b0a49 + _0x357b5a(0x171) + _0x2b0a49 + _0x357b5a(0x17f) + _0x2b0a49 + '𝐠𝐞𝐭𝐟𝐢𝐥𝐞\x0a-\x20' + _0x2b0a49 + '𝐬𝐚𝐥𝐯𝐚\x20(𝐩𝐥𝐮𝐠𝐢𝐧)\x0a-\x20' + _0x2b0a49 + _0x357b5a(0x153) + _0x2b0a49 + _0x357b5a(0x16e) + _0x2b0a49 + _0x357b5a(0x173) + _0x2b0a49 + _0x357b5a(0x17c) + _0x2b0a49 + _0x357b5a(0x163) + _0x2b0a49 + _0x357b5a(0x141) + _0x2b0a49 + _0x357b5a(0x159) + _0x2b0a49 + _0x357b5a(0x13a) + _0x2b0a49 + _0x357b5a(0x144) + _0x2b0a49 + '𝐫𝐢𝐦𝐮𝐨𝐯𝐢\x20(𝐧𝐮𝐦.\x20𝐦𝐞𝐬𝐬𝐚𝐠𝐠𝐢)\x20@\x0a────────────────')['trim'](), _0x575cba = global['db'][_0x357b5a(0x15f)]['nomedelbot'] || '𝐁𝐢𝐱𝐛𝐲𝐁𝐨𝐭-𝐌𝐝\x20🔮';
    _0x4d8805['sendMessage'](_0x1ece27['chat'], {
        'text': _0x3f08c2,
        'contextInfo': {
            'mentionedJid': _0x4d8805[_0x357b5a(0x15b)](wm),
            'forwardingScore': 0x1,
            'isForwarded': !![],
            'forwardedNewsletterMessageInfo': {
                'newsletterJid': _0x274e15[_0x357b5a(0x13c)],
                'serverMessageId': '',
                'newsletterName': '' + _0x575cba
            }
        }
    }, { 'quoted': _0x2d215f });
};
handler['help'] = [_0x2972a0(0x17a)], handler[_0x2972a0(0x17d)] = ['menu'], handler[_0x2972a0(0x17e)] = /^(owner|menuowner|pannello)$/i;
export default handler;
function clockString(_0xd0d91e) {
    const _0x1861b1 = _0x2972a0, _0xd2bc31 = {
            'IpObQ': function (_0x28c075, _0x413865) {
                return _0x28c075 / _0x413865;
            },
            'Gymwe': function (_0x4f63b9, _0x163f4b) {
                return _0x4f63b9 % _0x163f4b;
            },
            'YJFJI': function (_0x27c2ff, _0x5cd6f1) {
                return _0x27c2ff / _0x5cd6f1;
            }
        };
    let _0x27c45a = Math[_0x1861b1(0x164)](_0xd2bc31[_0x1861b1(0x14c)](_0xd0d91e, -0x8 * 0xb5a73 + -0x25804d * -0x1 + -0xf771d * -0x7)), _0x42617d = Math[_0x1861b1(0x164)](_0xd0d91e / (-0x16a65 + -0x1 * 0x109a7 + 0x35e6c)) % (0x46d * -0x2 + -0x3 * -0x7 + -0x1cd * -0x5), _0x1bf8dc = _0xd2bc31[_0x1861b1(0x14b)](Math[_0x1861b1(0x164)](_0xd2bc31['YJFJI'](_0xd0d91e, 0x336 + -0x89 * -0x25 + -0x43 * 0x49)), -0x44a + -0x2 * 0xa8c + 0x199e);
    return console[_0x1861b1(0x145)]({
        'ms': _0xd0d91e,
        'h': _0x27c45a,
        'm': _0x42617d,
        's': _0x1bf8dc
    }), [
        _0x27c45a,
        _0x42617d,
        _0x1bf8dc
    ][_0x1861b1(0x140)](_0x2d1849 => _0x2d1849[_0x1861b1(0x15a)]()['padStart'](0x240e + -0x1344 + 0x1 * -0x10c8, -0x1631 + 0x787 + -0x2 * -0x755))[_0x1861b1(0x179)](':');
}