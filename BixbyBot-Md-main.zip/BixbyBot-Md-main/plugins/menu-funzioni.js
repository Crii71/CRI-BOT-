function _0x5afc() {
    const _0x2387b8 = [
        'DhoBi',
        '4owfJJK',
        'Halo',
        '𝐝𝐢𝐬𝐚𝐛𝐢𝐥𝐢𝐭𝐚\x20𝐚𝐧𝐭𝐢𝐥𝐢𝐧𝐤\x0a>\x20ⓘ\x20𝐈𝐧𝐟𝐨\x20𝐬𝐮𝐥𝐥𝐨\x20𝐬𝐭𝐚𝐭𝐨\x0a>\x20',
        '16744WNwnRN',
        '𝐚𝐧𝐭𝐢𝐞𝐥𝐢𝐦𝐢𝐧𝐚\x0a────────────\x0a>\x20ⓘ\x20𝐈𝐧𝐟𝐨\x20𝐬𝐮𝐥𝐥𝐞\x20𝐟𝐮𝐧𝐳𝐢𝐨𝐧𝐢\x0a>\x20🟢\x20»\x20𝐅𝐮𝐧𝐳𝐢𝐨𝐧𝐞\x20𝐚𝐭𝐭𝐢𝐯𝐚𝐭𝐚\x20\x0a>\x20🔴\x20»\x20𝐅𝐮𝐧𝐳𝐢𝐨𝐧𝐞\x20𝐝𝐢𝐬𝐚𝐛𝐢𝐥𝐢𝐭𝐚𝐭𝐚\x20\x0a────────────\x0a>\x20ⓘ\x20𝐔𝐬𝐨\x20𝐝𝐞𝐥\x20𝐜𝐨𝐦𝐚𝐧𝐝𝐨\x0a>\x20',
        '𝐚𝐧𝐭𝐢𝐭𝐫𝐚𝐯𝐚\x0a\x20',
        '2778LxXsCq',
        'length',
        'LrulV',
        'now',
        '𝐝𝐞𝐭𝐞𝐜𝐭\x0a\x20',
        'floor',
        'memoryUsage',
        '1670499qeZNuo',
        '\x20»\x20',
        'map',
        'sendMessage',
        'isChats',
        'jid',
        'https://telegra.ph/file/2f38b3fd9cfba5935b496.jpg',
        'user',
        'fromMe',
        'trim',
        '𝐚𝐧𝐭𝐢𝐩𝐚𝐤𝐢\x0a\x20',
        'filter',
        'users',
        '𝐚𝐧𝐭𝐢𝐩𝐨𝐫𝐧𝐨\x0a\x20',
        '𝐚𝐧𝐭𝐢𝐭𝐢𝐤𝐭𝐨𝐤\x0a\x20',
        '𝐢𝐧𝐟𝐨𝐬𝐭𝐚𝐭𝐨\x0a──────────────',
        '𝐛𝐞𝐧𝐯𝐞𝐧𝐮𝐭𝐨\x0a\x20',
        'log',
        'opts',
        'quoted',
        '1696405jbRFbS',
        'menu',
        '1525488pAALBM',
        'chat',
        '𝐌𝐞𝐧𝐮\x20𝐝𝐞𝐥𝐥𝐞\x20𝐟𝐮𝐧𝐳𝐢𝐨𝐧𝐚𝐥𝐢𝐭𝐚\x27',
        'catch',
        '8CbisUo',
        'buffer',
        '𝐬𝐨𝐥𝐨𝐩𝐫𝐢𝐯𝐚𝐭𝐨\x0a\x20',
        'endsWith',
        'data',
        '𝐚𝐧𝐭𝐢𝐜𝐚𝐥𝐥\x0a\x20',
        'command',
        '80NowHPp',
        'getName',
        '𝐠𝐩𝐭\x0a\x20',
        '221511miJnHf',
        '𝐚𝐭𝐭𝐢𝐯𝐚\x20𝐚𝐧𝐭𝐢𝐥𝐢𝐧𝐤\x0a>\x20',
        'tags',
        '0@s.whatsapp.net',
        'image',
        'QNLmY',
        'mentionedJid',
        '@g.us',
        '14286168malLVx',
        'chats',
        'SWifb',
        'ippsH',
        'help',
        'sender',
        'keys',
        '120363175463922716@newsletter',
        'https://telegra.ph/file/8ca14ef9fa43e99d1d196.jpg',
        '11VcMoVB',
        './src/avatar_contact.png',
        '523036YztqRG',
        'padStart',
        '𝐛𝐚𝐧𝐠𝐩\x0a\x20',
        '𝐬𝐨𝐥𝐨𝐠𝐫𝐮𝐩𝐩𝐨\x0a\x20',
        'join',
        'nomedelbot',
        'profilePictureUrl',
        'qtkHA',
        '𝐚𝐧𝐭𝐢𝐢𝐧𝐬𝐭𝐚\x0a\x20',
        '\x0a──────────────\x0a\x20'
    ];
    _0x5afc = function () {
        return _0x2387b8;
    };
    return _0x5afc();
}
const _0x37b94a = _0x385d;
(function (_0x3d319f, _0x44712c) {
    const _0x32f0e8 = _0x385d, _0x5139b0 = _0x3d319f();
    while (!![]) {
        try {
            const _0x5d6a25 = parseInt(_0x32f0e8(0x143)) / (0xe98 + -0x14fc + 0x665 * 0x1) * (parseInt(_0x32f0e8(0xff)) / (0x2 * -0x5cb + -0x1d3 + -0xf * -0xe5)) + -parseInt(_0x32f0e8(0x130)) / (0x359 * 0x2 + -0x2301 + 0x1c52) + parseInt(_0x32f0e8(0x126)) / (0x2 * -0x3ce + 0xa0a + 0x26a * -0x1) * (-parseInt(_0x32f0e8(0x120)) / (0x23a * -0x1 + 0x1ce1 + -0x3ce * 0x7)) + parseInt(_0x32f0e8(0x105)) / (-0x206 + -0x978 + 0x2c * 0x43) * (parseInt(_0x32f0e8(0x102)) / (0x173b + 0x1 * 0x1431 + 0x1 * -0x2b65)) + -parseInt(_0x32f0e8(0x138)) / (-0xa09 + -0x36e + 0x2b3 * 0x5) + parseInt(_0x32f0e8(0x10c)) / (0xfdf + -0x7f2 + -0x7e4) * (parseInt(_0x32f0e8(0x12d)) / (0x24c3 + 0x1749 + 0x1 * -0x3c02)) + parseInt(_0x32f0e8(0x141)) / (0x22ee + -0x28 * -0x6c + -0x33c3 * 0x1) * (-parseInt(_0x32f0e8(0x122)) / (-0x1c2b * -0x1 + 0x2 * -0xfc7 + 0x36f));
            if (_0x5d6a25 === _0x44712c)
                break;
            else
                _0x5139b0['push'](_0x5139b0['shift']());
        } catch (_0x5d50b8) {
            _0x5139b0['push'](_0x5139b0['shift']());
        }
    }
}(_0x5afc, -0x74339 * 0x3 + -0x1 * 0x395c3 + -0x14c28 * -0x1f));
import _0x35ace9 from 'os';
import _0x56c04b from 'util';
import _0xe5b503 from 'human-readable';
import _0x762f55 from '@whiskeysockets/baileys';
import _0x58bebb from 'fs';
import { performance } from 'perf_hooks';
function _0x385d(_0x50c2d1, _0x5c6047) {
    const _0x30eac5 = _0x5afc();
    return _0x385d = function (_0x57a7b7, _0x3217cf) {
        _0x57a7b7 = _0x57a7b7 - (0xb * -0x258 + 0x3f1 + -0xb1 * -0x21);
        let _0x239abb = _0x30eac5[_0x57a7b7];
        return _0x239abb;
    }, _0x385d(_0x50c2d1, _0x5c6047);
}
let handler = async (_0x512ed3, {
    conn: _0x542b94,
    usedPrefix: _0x3f73c1
}) => {
    const _0x10a5dc = _0x385d, _0x35f496 = {
            'iSUoB': function (_0x1f46c9, _0x22d799) {
                return _0x1f46c9 * _0x22d799;
            },
            'DhoBi': function (_0x107e08, _0x19bdbb) {
                return _0x107e08(_0x19bdbb);
            },
            'LrulV': _0x10a5dc(0x134),
            'QNLmY': function (_0x3e7f78, _0x3a3ce6) {
                return _0x3e7f78(_0x3a3ce6);
            },
            'SWifb': _0x10a5dc(0x140),
            'ippsH': _0x10a5dc(0x100)
        };
    let _0x5267aa = _0x35f496['iSUoB'](process['uptime'](), -0x226f + -0x1 * -0x2653 + 0x4), _0x413977 = _0x35f496[_0x10a5dc(0xfe)](clockString, _0x5267aa), _0x2b6086 = Object[_0x10a5dc(0x13e)](global['db'][_0x10a5dc(0x12a)][_0x10a5dc(0x118)])[_0x10a5dc(0x106)];
    const _0x456717 = Object['entries'](_0x542b94[_0x10a5dc(0x139)])['filter'](([_0x5e8870, _0x10b39e]) => _0x5e8870 && _0x10b39e[_0x10a5dc(0x110)]), _0x58ea5d = _0x456717[_0x10a5dc(0x117)](([_0x2a5d99]) => _0x2a5d99[_0x10a5dc(0x129)](_0x10a5dc(0x137))), _0x33a890 = _0x456717[_0x10a5dc(0x117)](([_0x1fdcbe]) => _0x1fdcbe[_0x10a5dc(0x129)](_0x10a5dc(0x137))), _0x29f52b = process[_0x10a5dc(0x10b)](), {restrict: _0x51ac65} = global['db']['data']['settings'][_0x542b94[_0x10a5dc(0x113)][_0x10a5dc(0x111)]] || {}, {autoread: _0x54104a} = global[_0x10a5dc(0x11e)], _0x4f4cb8 = './no.png';
    let _0x3d8872 = performance[_0x10a5dc(0x108)](), _0x40e3d2 = performance[_0x10a5dc(0x108)](), _0x5223eb = _0x40e3d2 - _0x3d8872, _0x15117d = await _0x542b94[_0x10a5dc(0x12e)](_0x512ed3[_0x10a5dc(0x13d)]);
    const {
        antiToxic: _0x335a3d,
        antilinkhard: _0x43883e,
        antiPrivate: _0x25448d,
        antitraba: _0x7ca884,
        antiArab: _0x17a77a,
        antiviewonce: _0x49dd3d,
        isBanned: _0xf22dbc,
        welcome: _0x16d809,
        detect: _0x4c3a9f,
        sWelcome: _0x5282a4,
        sBye: _0xc22b07,
        sPromote: _0x3ed8d1,
        sDemote: _0x567cbe,
        antiLink: _0x54e7f7,
        antilinkbase: _0x2045a1,
        antitiktok: _0x1ada34,
        sologruppo: _0x2db392,
        soloprivato: _0x19b996,
        antiCall: _0xe348e8,
        modohorny: _0xc91cf2,
        gpt: _0x203d53,
        antiinsta: _0x2dc78c,
        antielimina: _0x45cbee,
        antitelegram: _0x17aa1e,
        antiSpam: _0x50dc87,
        antiPorno: _0x1fa650,
        jadibot: _0x4d2095,
        autosticker: _0x4843dc,
        modoadmin: _0xe6402c,
        audios: _0x6ec887
    } = global['db']['data'][_0x10a5dc(0x139)][_0x512ed3['chat']];
    let _0x5bfb0b = _0x512ed3[_0x10a5dc(0x11f)] ? _0x512ed3[_0x10a5dc(0x11f)]['sender'] : _0x512ed3[_0x10a5dc(0x136)] && _0x512ed3[_0x10a5dc(0x136)][0xc90 + -0xf74 + 0x2e4] ? _0x512ed3[_0x10a5dc(0x136)][0x4 * -0x11f + 0xcb9 * -0x1 + 0x1135] : _0x512ed3[_0x10a5dc(0x114)] ? _0x542b94[_0x10a5dc(0x113)][_0x10a5dc(0x111)] : _0x512ed3[_0x10a5dc(0x13d)];
    const _0x197a8a = await _0x542b94[_0x10a5dc(0xfa)](_0x5bfb0b, _0x35f496[_0x10a5dc(0x107)])[_0x10a5dc(0x125)](_0x2cb040 => null) || _0x10a5dc(0x142);
    let _0x53e6f1;
    _0x197a8a !== _0x10a5dc(0x142) ? _0x53e6f1 = await (await fetch(_0x197a8a))[_0x10a5dc(0x127)]() : _0x53e6f1 = await (await _0x35f496[_0x10a5dc(0x135)](fetch, _0x35f496[_0x10a5dc(0x13a)]))['buffer']();
    let _0x6bd16e = {
            'key': {
                'participants': _0x10a5dc(0x133),
                'fromMe': ![],
                'id': _0x35f496[_0x10a5dc(0x13b)]
            },
            'message': {
                'locationMessage': {
                    'name': _0x10a5dc(0x124),
                    'jpegThumbnail': await (await fetch(_0x10a5dc(0x112)))[_0x10a5dc(0x127)]()
                }
            },
            'participant': _0x10a5dc(0x133)
        }, _0x2aa101 = (_0x10a5dc(0xfd) + (_0x4c3a9f ? '🟢' : '🔴') + _0x10a5dc(0x10d) + _0x3f73c1 + _0x10a5dc(0x109) + (_0x203d53 ? '🟢' : '🔴') + _0x10a5dc(0x10d) + _0x3f73c1 + _0x10a5dc(0x12f) + (_0x4d2095 ? '🟢' : '🔴') + '\x20»\x20' + _0x3f73c1 + '𝐣𝐚𝐝𝐢𝐛𝐨𝐭\x0a\x20' + (_0x16d809 ? '🟢' : '🔴') + '\x20»\x20' + _0x3f73c1 + _0x10a5dc(0x11c) + (_0x2db392 ? '🟢' : '🔴') + _0x10a5dc(0x10d) + _0x3f73c1 + _0x10a5dc(0x146) + (_0x19b996 ? '🟢' : '🔴') + _0x10a5dc(0x10d) + _0x3f73c1 + _0x10a5dc(0x128) + (_0xe6402c ? '🟢' : '🔴') + _0x10a5dc(0x10d) + _0x3f73c1 + '𝐦𝐨𝐝𝐨𝐚𝐝𝐦𝐢𝐧\x0a\x20' + (_0xf22dbc ? '🟢' : '🔴') + _0x10a5dc(0x10d) + _0x3f73c1 + _0x10a5dc(0x145) + (_0x1fa650 ? '🟢' : '🔴') + _0x10a5dc(0x10d) + _0x3f73c1 + _0x10a5dc(0x119) + (_0xe348e8 ? '🟢' : '🔴') + _0x10a5dc(0x10d) + _0x3f73c1 + _0x10a5dc(0x12b) + (_0x7ca884 ? '🟢' : '🔴') + '\x20»\x20' + _0x3f73c1 + _0x10a5dc(0x104) + (_0x17a77a ? '🟢' : '🔴') + _0x10a5dc(0x10d) + _0x3f73c1 + _0x10a5dc(0x116) + (_0x54e7f7 ? '🟢' : '🔴') + _0x10a5dc(0x10d) + _0x3f73c1 + '𝐚𝐧𝐭𝐢𝐥𝐢𝐧𝐤\x0a\x20' + (_0x2dc78c ? '🟢' : '🔴') + '\x20»\x20' + _0x3f73c1 + _0x10a5dc(0xfc) + (_0x1ada34 ? '🟢' : '🔴') + '\x20»\x20' + _0x3f73c1 + _0x10a5dc(0x11a) + (_0x45cbee ? '🟢' : '🔴') + _0x10a5dc(0x10d) + _0x3f73c1 + _0x10a5dc(0x103) + _0x3f73c1 + _0x10a5dc(0x131) + _0x3f73c1 + _0x10a5dc(0x101) + _0x3f73c1 + _0x10a5dc(0x11b))[_0x10a5dc(0x115)](), _0x238ca2 = global['db']['data'][_0x10a5dc(0x148)] || '𝐁𝐢𝐱𝐛𝐲𝐁𝐨𝐭-𝐌𝐝\x20🔮';
    _0x542b94[_0x10a5dc(0x10f)](_0x512ed3[_0x10a5dc(0x123)], {
        'text': _0x2aa101,
        'contextInfo': {
            'mentionedJid': _0x542b94['parseMention'](wm),
            'forwardingScore': 0x1,
            'isForwarded': !![],
            'forwardedNewsletterMessageInfo': {
                'newsletterJid': _0x10a5dc(0x13f),
                'serverMessageId': '',
                'newsletterName': '' + _0x238ca2
            }
        }
    }, { 'quoted': _0x6bd16e });
};
handler[_0x37b94a(0x13c)] = [_0x37b94a(0x121)], handler[_0x37b94a(0x132)] = [_0x37b94a(0x121)], handler[_0x37b94a(0x12c)] = /^(funzioni)$/i;
export default handler;
function clockString(_0x5a16ee) {
    const _0xbe0cb6 = _0x37b94a, _0x50f118 = {
            'tfcIS': function (_0x4c9ae9, _0x4f0e5a) {
                return _0x4c9ae9 / _0x4f0e5a;
            },
            'qtkHA': function (_0x5cdaa9, _0x533f2b) {
                return _0x5cdaa9 / _0x533f2b;
            }
        };
    let _0x275dc8 = Math[_0xbe0cb6(0x10a)](_0x50f118['tfcIS'](_0x5a16ee, 0x1656 * -0x4ab + -0x11d3e4 + 0xb105d6)), _0x440496 = Math[_0xbe0cb6(0x10a)](_0x50f118[_0xbe0cb6(0xfb)](_0x5a16ee, -0x1fcc * -0x8 + 0x1023e + 0x346 * -0x55)) % (-0xdd7 * 0x2 + 0x17c4 + 0x426), _0xc6485c = Math[_0xbe0cb6(0x10a)](_0x50f118[_0xbe0cb6(0xfb)](_0x5a16ee, -0x198e + 0xcb4 + 0x10c2)) % (0x2 * -0xa02 + 0x2429 * -0x1 + -0x3869 * -0x1);
    return console[_0xbe0cb6(0x11d)]({
        'ms': _0x5a16ee,
        'h': _0x275dc8,
        'm': _0x440496,
        's': _0xc6485c
    }), [
        _0x275dc8,
        _0x440496,
        _0xc6485c
    ][_0xbe0cb6(0x10e)](_0xc31c1 => _0xc31c1['toString']()[_0xbe0cb6(0x144)](0x3 * 0x807 + 0x35 * -0x5e + -0x49d, 0x3c3 + -0x30e + -0x1 * 0xb5))[_0xbe0cb6(0x147)](':');
}