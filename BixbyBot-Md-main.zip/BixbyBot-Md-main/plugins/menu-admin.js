const _0x4fb728 = _0x289c;
(function (_0x2123c0, _0x3b0211) {
    const _0x3fdc2e = _0x289c, _0x43d79d = _0x2123c0();
    while (!![]) {
        try {
            const _0x427c1b = parseInt(_0x3fdc2e(0x10e)) / (0x6a3 * 0x1 + -0x1 * -0x1cd5 + 0x1 * -0x2377) + -parseInt(_0x3fdc2e(0x110)) / (0x17b * -0x9 + -0x1a42 + 0x2797 * 0x1) * (parseInt(_0x3fdc2e(0x123)) / (0x970 + 0x1a51 + -0x23be)) + -parseInt(_0x3fdc2e(0x102)) / (-0x606 * -0x5 + 0x1090 + -0x2eaa) + -parseInt(_0x3fdc2e(0x112)) / (0x311 + -0x13c7 + -0x1 * -0x10bb) + -parseInt(_0x3fdc2e(0x121)) / (0x6f * 0x3b + -0x9a0 + -0xfef) + parseInt(_0x3fdc2e(0x132)) / (0x11ff + -0x16ba + 0x4c2) * (parseInt(_0x3fdc2e(0x119)) / (0x1f4f + -0x213 * 0x9 + -0xc9c)) + -parseInt(_0x3fdc2e(0x111)) / (-0x1f95 + -0xf1 * 0xb + 0x5ff * 0x7) * (-parseInt(_0x3fdc2e(0x11e)) / (-0x1 * 0x20ee + -0x2250 + 0x21a4 * 0x2));
            if (_0x427c1b === _0x3b0211)
                break;
            else
                _0x43d79d['push'](_0x43d79d['shift']());
        } catch (_0x297bac) {
            _0x43d79d['push'](_0x43d79d['shift']());
        }
    }
}(_0x1183, 0x1 * 0x52b3b + 0xac883 + -0x1 * 0x83d79));
import _0x19910d from 'os';
import _0x3006de from 'util';
import _0x3bd000 from 'human-readable';
import _0x12ad11 from '@whiskeysockets/baileys';
import _0x2470f1 from 'fs';
import { performance } from 'perf_hooks';
function _0x289c(_0x549c4d, _0xa23c6d) {
    const _0x2727fc = _0x1183();
    return _0x289c = function (_0x392e15, _0x2246bb) {
        _0x392e15 = _0x392e15 - (-0xdd6 + 0xf86 + -0xb0);
        let _0x4f4adf = _0x2727fc[_0x392e15];
        return _0x4f4adf;
    }, _0x289c(_0x549c4d, _0xa23c6d);
}
let handler = async (_0x4955de, {
    conn: _0x4b9a49,
    usedPrefix: _0xeb2cc9
}) => {
    const _0x30ade0 = _0x289c, _0x421427 = {
            'BUwoV': function (_0x15a7b4, _0x4d9837) {
                return _0x15a7b4(_0x4d9837);
            },
            'CSLnr': _0x30ade0(0x10b),
            'bIIrt': function (_0x3b5cc8, _0x147848) {
                return _0x3b5cc8 - _0x147848;
            },
            'Lidmd': _0x30ade0(0x100),
            'RnDry': 'Halo',
            'zsntY': _0x30ade0(0x11a)
        };
    let _0x2f0639 = process[_0x30ade0(0x107)]() * (0xade + 0x380 * -0x7 + 0x118a), _0x173669 = _0x421427['BUwoV'](clockString, _0x2f0639), _0x906917 = Object[_0x30ade0(0x122)](global['db'][_0x30ade0(0x11c)]['users'])[_0x30ade0(0x108)];
    const _0x7dd0ea = Object[_0x30ade0(0x130)](_0x4b9a49[_0x30ade0(0x12e)])['filter'](([_0x3002a9, _0xe6ea51]) => _0x3002a9 && _0xe6ea51[_0x30ade0(0x101)]), _0x17bf29 = _0x7dd0ea[_0x30ade0(0x11f)](([_0xf99b63]) => _0xf99b63[_0x30ade0(0x131)]('@g.us')), _0x1cfea8 = _0x7dd0ea[_0x30ade0(0x11f)](([_0x691a1f]) => _0x691a1f[_0x30ade0(0x131)](_0x30ade0(0x138))), _0x34452c = process[_0x30ade0(0x118)](), {restrict: _0x5b8c48} = global['db'][_0x30ade0(0x11c)]['settings'][_0x4b9a49[_0x30ade0(0x11b)][_0x30ade0(0x136)]] || {}, {autoread: _0x73d76f} = global[_0x30ade0(0x104)], _0x3d65b2 = _0x421427[_0x30ade0(0x127)];
    let _0x439cf5 = performance['now'](), _0x34740d = performance['now'](), _0x3f7d2d = _0x421427[_0x30ade0(0x13e)](_0x34740d, _0x439cf5), _0x31458b = await _0x4b9a49[_0x30ade0(0x124)](_0x4955de[_0x30ade0(0x13b)]), _0x414c2d = {
            'key': {
                'participants': _0x421427['Lidmd'],
                'fromMe': ![],
                'id': _0x421427[_0x30ade0(0x120)]
            },
            'message': {
                'locationMessage': {
                    'name': '𝐌𝐞𝐧𝐮\x20𝐀𝐝𝐦𝐢𝐧',
                    'jpegThumbnail': await (await fetch(_0x421427[_0x30ade0(0x12b)]))[_0x30ade0(0x10c)](),
                    'vcard': _0x30ade0(0x10a)
                }
            },
            'participant': _0x421427[_0x30ade0(0x106)]
        }, _0x259d4e = ('\x0a══════\x20•⊰✧‌⊱•\x20══════\x0a-\x20' + _0xeb2cc9 + _0x30ade0(0x105) + _0xeb2cc9 + _0x30ade0(0x103) + _0xeb2cc9 + _0x30ade0(0x12c) + _0xeb2cc9 + _0x30ade0(0x116) + _0xeb2cc9 + _0x30ade0(0x137) + _0xeb2cc9 + '𝐭𝐚𝐠𝐚𝐥𝐥\x20/\x20𝐦𝐚𝐫𝐜𝐚𝐫\x0a-\x20' + _0xeb2cc9 + _0x30ade0(0x135) + _0xeb2cc9 + '𝐬𝐞𝐭𝐰𝐞𝐥𝐜𝐨𝐦𝐞\x0a-\x20' + _0xeb2cc9 + _0x30ade0(0x109) + _0xeb2cc9 + _0x30ade0(0x126) + _0xeb2cc9 + _0x30ade0(0x125) + _0xeb2cc9 + _0x30ade0(0x12f))[_0x30ade0(0x133)](), _0xf5c7c0 = global['db']['data'][_0x30ade0(0x13d)] || _0x30ade0(0x113);
    _0x4b9a49[_0x30ade0(0x11d)](_0x4955de['chat'], {
        'text': _0x259d4e,
        'contextInfo': {
            'mentionedJid': _0x4b9a49[_0x30ade0(0x129)](wm),
            'forwardingScore': 0x1,
            'isForwarded': !![],
            'forwardedNewsletterMessageInfo': {
                'newsletterJid': _0x30ade0(0x12d),
                'serverMessageId': '',
                'newsletterName': '' + _0xf5c7c0
            }
        }
    }, { 'quoted': _0x414c2d });
};
handler[_0x4fb728(0x134)] = [_0x4fb728(0x115)], handler['tags'] = [_0x4fb728(0x115)], handler[_0x4fb728(0x13c)] = /^(menuadm|admin)$/i;
function _0x1183() {
    const _0x330b29 = [
        'toString',
        'zsntY',
        '𝐰𝐚𝐫𝐧\x20/\x20𝐮𝐧𝐰𝐚𝐫𝐧\x0a-\x20',
        '120363175463922716@newsletter',
        'chats',
        '𝐩𝐮𝐥𝐢𝐳𝐢𝐚\x20+\x20𝐩𝐫𝐞𝐟𝐢𝐬𝐬𝐨\x0a══════\x20•⊰✧‌⊱•\x20══════',
        'entries',
        'endsWith',
        '555177ItTysh',
        'trim',
        'help',
        '𝐚𝐩𝐞𝐫𝐭𝐨\x20/\x20𝐜𝐡𝐢𝐮𝐬𝐨\x0a-\x20',
        'jid',
        '𝐡𝐢𝐝𝐞𝐭𝐚𝐠\x0a-\x20',
        '@g.us',
        'padStart',
        'log',
        'sender',
        'command',
        'nomedelbot',
        'bIIrt',
        '0@s.whatsapp.net',
        'isChats',
        '2660224zyxjbE',
        '𝐫𝐞𝐭𝐫𝐨𝐜𝐞𝐝𝐢\x20/\x20𝐭𝐨𝐠𝐥𝐢𝐚𝐝𝐦𝐢𝐧\x20@\x0a-\x20',
        'opts',
        '𝐩𝐫𝐨𝐦𝐮𝐨𝐯𝐢\x20/\x20𝐦𝐞𝐭𝐭𝐢𝐚𝐝𝐦𝐢𝐧\x20@\x0a-\x20',
        'Lidmd',
        'uptime',
        'length',
        '𝐬𝐞𝐭𝐛𝐲𝐞\x0a-\x20',
        'BEGIN:VCARD\x0aVERSION:3.0\x0aN:;Unlimited;;;\x0aFN:Unlimited\x0aORG:Unlimited\x0aTITLE:\x0aitem1.TEL;waid=19709001746:+1\x20(970)\x20900-1746\x0aitem1.X-ABLabel:Unlimited\x0aX-WA-BIZ-DESCRIPTION:ofc\x0aX-WA-BIZ-NAME:Unlimited\x0aEND:VCARD',
        './no.png',
        'buffer',
        'floor',
        '373934zVKGJg',
        'cHHKx',
        '73322ZGaQmq',
        '10688742BjSCqS',
        '1237870TqJdTA',
        '𝐁𝐢𝐱𝐛𝐲𝐁𝐨𝐭-𝐌𝐝\x20🔮',
        'VmrgF',
        'menu',
        '𝐦𝐮𝐭𝐚\x20/\x20𝐬𝐦𝐮𝐭𝐚\x0a-\x20',
        'map',
        'memoryUsage',
        '8dutzDm',
        'https://telegra.ph/file/2f38b3fd9cfba5935b496.jpg',
        'user',
        'data',
        'sendMessage',
        '10BwYAoj',
        'filter',
        'RnDry',
        '237210EwUVWl',
        'keys',
        '15iKpNBq',
        'getName',
        '𝐥𝐢𝐬𝐭𝐚𝐧𝐮𝐦\x20+\x20𝐩𝐫𝐞𝐟𝐢𝐬𝐬𝐨\x0a-\x20',
        '𝐢𝐧𝐚𝐭𝐭𝐢𝐯𝐢\x0a-\x20',
        'CSLnr',
        'bmaFz',
        'parseMention'
    ];
    _0x1183 = function () {
        return _0x330b29;
    };
    return _0x1183();
}
export default handler;
function clockString(_0x5dad08) {
    const _0x4f821f = _0x4fb728, _0x146754 = {
            'VmrgF': function (_0x14aa32, _0x2eedc0) {
                return _0x14aa32 / _0x2eedc0;
            },
            'bmaFz': function (_0x107ab6, _0x3144c3) {
                return _0x107ab6 % _0x3144c3;
            },
            'cHHKx': function (_0x57a514, _0x3a29da) {
                return _0x57a514 / _0x3a29da;
            }
        };
    let _0x233c78 = Math['floor'](_0x146754[_0x4f821f(0x114)](_0x5dad08, 0x6791cf + 0x3f0a58 + 0x1 * -0x6fada7)), _0x2b10bc = _0x146754[_0x4f821f(0x128)](Math['floor'](_0x146754[_0x4f821f(0x114)](_0x5dad08, 0x1b2cd + 0x31 * -0x22 + 0xc1eb * -0x1)), 0x1548 + 0xe68 * -0x2 + 0x7c4), _0x2c7d73 = Math[_0x4f821f(0x10d)](_0x146754[_0x4f821f(0x10f)](_0x5dad08, -0x1 * 0x19ef + 0x25ef + -0x818)) % (0x583 + 0x45e + -0x9a5);
    return console[_0x4f821f(0x13a)]({
        'ms': _0x5dad08,
        'h': _0x233c78,
        'm': _0x2b10bc,
        's': _0x2c7d73
    }), [
        _0x233c78,
        _0x2b10bc,
        _0x2c7d73
    ][_0x4f821f(0x117)](_0x4bd0ef => _0x4bd0ef[_0x4f821f(0x12a)]()[_0x4f821f(0x139)](0xdf9 * -0x1 + 0x1568 + 0x1 * -0x76d, 0x76 * -0x11 + 0x261 + 0x575))['join'](':');
}